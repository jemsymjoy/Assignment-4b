package org.o7planning.sbdatajpa.controller;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.o7planning.sbdatajpa.Account;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class MainController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MainController.class);

	RestTemplate restTemplate = new RestTemplate();
	
	
	/*
	 * //IGNORE HOME METHOD
	 * 
	 * @ResponseBody
	 * 
	 * @RequestMapping("/") public String home() { String html = ""; html += "<ul>";
	 * html += " <li><a href='/addAccount'>Add Account</a></li>"; html +=
	 * " <li><a href='/getAccountGivenAccountNumber'>Fetch Account Given Account Number</a></li>"
	 * ; html +=
	 * " <li><a href='/getAccountGivenAccountType'>Fetch Accounts Given Account Type</a></li>"
	 * ; html +=
	 * " <li><a href='/updateBalanceAmount'>Update Balance Amount</a></li>"; html +=
	 * " <li><a href='/updateAccountStatus'>Update Account Status</a></li>"; html +=
	 * "</ul>"; return html; }
	 */

	
	  //ADD ACCOUNT: RETURN String
	  
	  @RequestMapping(value = "/addAccount", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE) 
	  public String addAccount(@RequestBody Account account) {
		  LOGGER.info("---- Main Controller: Add Account");
		  HttpHeaders headers=new HttpHeaders();
		  headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		  HttpEntity<Account> entity=new HttpEntity<Account>(account,headers);
		  return restTemplate.exchange("http://localhost:8080/addAccount", HttpMethod.POST,entity,String.class).getBody();
	  }
	 
    
    //GET ACCOUNT GIVEN ACCOUNT TYPE: RETURN STRING
    @RequestMapping(value = "/getAccountGivenAccountType/{type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getAccountWithType(@PathVariable("type") String type) {
    	LOGGER.info("--- Main Controller's Get Account Given Account Type");
    	HttpHeaders headers=new HttpHeaders();
    	headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    	HttpEntity<String> entity=new HttpEntity<String>(headers);
    	return restTemplate.exchange("http://localhost:8080/getAccountGivenAccountType/"+type, HttpMethod.GET,entity,String.class).getBody();
    	
    }
	
    //GET ACCOUNT GIVEN ACCOUNT NUMBER : RETURN STRING
	  @RequestMapping(value = "/getAccountGivenAccountNumber/{number}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE) 
	  public String getAccountWithNumber(@PathVariable("number") BigInteger number) {
		  LOGGER.info("--- Main Controller's Get Account Given Account Number");
		  HttpHeaders headers=new HttpHeaders();
		  headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		  HttpEntity<String> entity=new HttpEntity<String>(headers);
		  return restTemplate.exchange("http://localhost:8080/getAccountGivenAccountNumber/"+number, HttpMethod.GET,entity,String.class).getBody();
  	}
	  
	//UPDATE BALANCE AMOUNT GIVEN ACCOUNT NUMBER AND AMOUNT : RETURN String
	@RequestMapping(value = "/updateBalanceAmount/{number}/{amount}", method =RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE) 
	  public  String updateAmount(@PathVariable("number") BigInteger accountNumber,@PathVariable("amount") BigDecimal amount) {
		  LOGGER.info("--- Main Controller: Update Balance Amount");
		 HttpHeaders headers=new HttpHeaders();
		  LOGGER.info("After the HttpHeaders");
				  
		  headers.setContentType(MediaType.APPLICATION_JSON);
		  headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		  LOGGER.info("After the MediaType"); 
		  
		  HttpEntity<String> entity=new HttpEntity<String>(headers);
		 return restTemplate.exchange("http://localhost:8080/updateBalanceAmount/"+accountNumber+"/"+amount, HttpMethod.POST,entity,String.class).getBody();
			  
	  }
	  
	  //UPDATE ACCOUNT STATUS :RETURN STRING
	  @RequestMapping(value = "/updateAccountStatus/{number}/{status}", method =RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE) 
	  public  String updateStatus(@PathVariable("number") BigInteger accountNumber,@PathVariable("status") char status) {
		  LOGGER.info("--- Main Controller: Update Account Status");
			 HttpHeaders headers=new HttpHeaders();
			  headers.setContentType(MediaType.APPLICATION_JSON);
			  headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			  
			  HttpEntity<String> entity=new HttpEntity<String>(headers);
			 return restTemplate.exchange("http://localhost:8080/updateAccountStatus/"+accountNumber+"/"+Character.toString(status), HttpMethod.POST,entity,String.class).getBody();
			
	  }
	 
	 
}