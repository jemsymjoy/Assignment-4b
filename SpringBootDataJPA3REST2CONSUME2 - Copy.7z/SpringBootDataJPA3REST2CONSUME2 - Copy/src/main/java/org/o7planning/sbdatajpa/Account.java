package org.o7planning.sbdatajpa;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

public class Account {
 
private String name;
private BigInteger accountNumber; //length=15
private String accountType1;//Deposit, Personal Loan, Home Loan, Student Loan
private LocalDate accountOpenDate;//yyyy-MM-dd
private char status;//A,C,F - Active, Closed, Freeze
private String accountType2;//Main, Authorized
private BigDecimal balance; //Number(18,2)
	
	 //Getters & Setters

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public BigInteger getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getAccountType1() {
		return accountType1;
	}


	public void setAccountType1(String accountType1) {
		this.accountType1 = accountType1;
	}


	public LocalDate getAccountOpenDate() {
		return accountOpenDate;
	}


	public void setAccountOpenDate(LocalDate accountOpenDate) {
		this.accountOpenDate = accountOpenDate;
	}


	public char getStatus() {
		return status;
	}


	public void setStatus(char status) {
		this.status = status;
	}


	public String getAccountType2() {
		return accountType2;
	}


	public void setAccountType2(String accountType2) {
		this.accountType2 = accountType2;
	}


	public BigDecimal getBalance() {
		return balance;
	}


	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}


	@Override
    public String toString() {
        return this.getAccountNumber() + ", " + this.getName();
    }
 
}